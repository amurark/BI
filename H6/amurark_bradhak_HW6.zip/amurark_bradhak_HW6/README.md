===================================== README =====================================
                  Authors: Ankit Murarka, Balaji Radhakrishnan

1. 2 Datasets are included along with the submission, either can be used
2. To run the python script, use the following command:
          '''
            python sqd1.py <winequality-white.csv> Learning_rate Epochs
          '''
3. 'Learning_rate' is in the range 0 to 0.1
4. 'Epochs' is in the range 1 to 100
5. We used the following script:
          '''
            python sqd1.py winequality-red.csv 0.01 50
          '''
6. The code uses Scikit-learn's 'linear_model.LinearRegression' to compare results.

====================================== END ======================================
