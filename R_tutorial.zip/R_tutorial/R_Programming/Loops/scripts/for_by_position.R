# You're about to write for-loop in R that accesses a sequence by the position of each element! 

# Save the script before typing submit() in the console after you edit it.

for_by_position <- function(n=3) {
  my_sequence <- c(1:n)
  msg<-""
  # Code the for-loop construct
   
  # Return the resulting msg
  
}
