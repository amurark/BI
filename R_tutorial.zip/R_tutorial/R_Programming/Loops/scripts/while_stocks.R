# You're about to write a while-loop in R! 

# Save the script before typing submit() in the console after you edit it.

while_stocks<- function(price) {

  # Initialize the stock_price with the passed argument value
  stock_price <- price
  attempt <- 0

  # As long as stock_price is higher than 25,
  # decrease the stock_price by 5
  
  
  # Return the resulting msg
  attempt
  
}
